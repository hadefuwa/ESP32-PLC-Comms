#ifndef PLATFORM_H
#define PLATFORM_H

// ============================================================================
//  Simplified ESP32 WiFi-only Platform Header for Settimino / Snap7
// ============================================================================

#include <WiFi.h>

// Define WiFi socket type for all S7 TCP communications
#define S7WIFI
#define TCP_TIMEOUT 3000
typedef WiFiClient TCPClient;

#endif // PLATFORM_H
